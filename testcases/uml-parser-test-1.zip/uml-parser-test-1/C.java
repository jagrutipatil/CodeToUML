 

public class C {
 
	private A a;
	 
}
 
